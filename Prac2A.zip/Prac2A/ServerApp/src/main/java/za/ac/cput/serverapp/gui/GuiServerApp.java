package za.ac.cput.serverapp.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import za.ac.cput.serverapp.ServerApp;

/**
 *
 * @author 230333907
 */
public class GuiServerApp extends JFrame implements ActionListener{
    
    private ServerSocket listener;
    private String msg = "";
    private String upCaseMsg = "";
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private JButton exitBtn = new JButton("EXIT");
    private JTextArea clientTxtArea = new JTextArea(5,40);
    private String response = "";
    private JPanel topPanel = new JPanel();
    private JPanel centerPanel = new JPanel();
    
    public GuiServerApp(){
        
        topPanel.add(exitBtn);
        centerPanel.add(clientTxtArea);
        
        this.setLayout(new BorderLayout());
        this.add(topPanel, BorderLayout.NORTH);
        this.add(centerPanel, BorderLayout.CENTER);
        
        this.setVisible(true);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        exitBtn.addActionListener(this);
    
    }
    
    public void listenForClients() throws IOException
    {
        ServerApp listener = new ServerApp();
       
        
    }
    
    public static void main(String[] args) {
        GuiServerApp server = new GuiServerApp();
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== exitBtn){
            this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        }
    }
    
}
